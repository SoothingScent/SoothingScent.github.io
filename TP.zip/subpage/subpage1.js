$(function(){
    $('.MainMenu1').mouseenter(function(){
         $('.MMenu1').stop().animate({
            height: '200px'
         },);
    });
    $('.MainMenu1').mouseleave(function(){
         $('.MMenu1').stop().animate({
            height: '0px'   
         },);
    });
    $('.MMenu1').mouseenter(function(){
        $('.MMenu1').stop().animate({
           height: '200px'
        },);
   });
   $('.MMenu1').mouseleave(function(){
    $('.MMenu1').stop().animate({
       height: '0px'   
    },);
});
});

$(function(){
    $('.MainMenu2').mouseenter(function(){
         $('.MMenu2').stop().animate({
            height: '200px'
         },);
     });
     $('.MainMenu2').mouseleave(function(){
         $('.MMenu2').stop().animate({
            height: '0px'   
         },);
     });
     $('.MMenu2').mouseenter(function(){
        $('.MMenu2').stop().animate({
           height: '200px'
        },);
    });
    $('.MMenu2').mouseleave(function(){
        $('.MMenu2').stop().animate({
           height: '0px'   
        },);
    });
});
$(function(){
    $('.MainMenu3').mouseenter(function(){
         $('.MMenu3').stop().animate({
            height: '200px'
         },);
     });
     $('.MainMenu3').mouseleave(function(){
         $('.MMenu3').stop().animate({
            height: '0px'   
         },);
     });
     $('.MMenu3').mouseenter(function(){
        $('.MMenu3').stop().animate({
           height: '200px'
        },);
    });
    $('.MMenu3').mouseleave(function(){
        $('.MMenu3').stop().animate({
           height: '0px'   
        },);
    });
});
$(function(){
    $('.MainMenu4').mouseenter(function(){
         $('.MMenu4').stop().animate({
            height: '200px'
         },);
     });
     $('.MainMenu4').mouseleave(function(){
         $('.MMenu4').stop().animate({
            height: '0px'   
         },);
     });
     $('.MMenu4').mouseenter(function(){
        $('.MMenu4').stop().animate({
           height: '200px'
        },);
    });
    $('.MMenu4').mouseleave(function(){
        $('.MMenu4').stop().animate({
           height: '0px'   
        },);
    });
});
$(function(){
    $('.MainMenu5').mouseenter(function(){
         $('.MMenu5').stop().animate({
            height: '200px'
         },);
     });
     $('.MainMenu5').mouseleave(function(){
         $('.MMenu5').stop().animate({
            height: '0px'   
         },);
     });
     $('.MMenu5').mouseenter(function(){
        $('.MMenu5').stop().animate({
           height: '200px'
        },);
    });
    $('.MMenu5').mouseleave(function(){
        $('.MMenu5').stop().animate({
           height: '0px'   
        },);
    });
});